    int vect[100];
