    extern char ** environ;
