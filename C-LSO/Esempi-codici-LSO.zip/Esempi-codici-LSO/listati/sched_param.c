struct sched_param {
    int sched_priority;
};
