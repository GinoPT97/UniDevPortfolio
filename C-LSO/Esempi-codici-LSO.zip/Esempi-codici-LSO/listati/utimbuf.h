struct utimbuf {
        time_t actime;  /* access time */
        time_t modtime; /* modification time */
};
